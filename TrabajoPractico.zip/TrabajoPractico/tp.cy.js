
describe('Trabajo Practico', () => {
    beforeEach('should visit the page', () => {
        //visita la pagina antes de cada prueba

        cy.visit('https://automationintesting.online/');
    });

    it('Verificar que la dirección esté presente en la página', () => {
       
        cy.get ('div').contains('Shady Meadows B&B').should('exist');

    });

    it('Verificar que se encuentren las imagenes',()=>{

        cy.get('img[src="/images/rbp-logo.jpg"]').should('exist');

        cy.get('img[src="/images/room2.jpg"]');
    })

    it('Verificar que el texto este presente en la pagina',()=>{

        cy.get('p').contains('Welcome to Shady Meadows, a delightful Bed & Breakfast nestled in the hills on Newingtonfordburyshire. A place so beautiful you will never want to leave. All our rooms have comfortable beds and we provide breakfast from the locally sourced supermarket. It is a delightful place.')
    })


});
    